from SavingAccount  import SavingAccount

sv = SavingAccount()
sv.newAccount()
sv.svInput()
sv.svShow()
sv.svShow(444555)
sv.show()
