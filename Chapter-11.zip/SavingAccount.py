from BankAccount import BankAccount

class SavingAccount(BankAccount):

     def svInput(s):
          s.amt = int(input('enter amt :'))

     #def svShow(s):
     #     print(s.amt)

     def svShow(s,tax=0) :
          print(s.amt)
          print(tax)
