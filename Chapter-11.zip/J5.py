class student:
     def input_data(s): #			to input the data
          s.rollno = int( input('enter roll no:'))
          s.name = input('enter name:')
          s.address =input('enter address :')
          s.city =input('enter city :')
          s.country =input('enter country :')


     def Retroll(s):
          return s.rollno
          
     def disp(ab):#				to display the data
          print('roll no :',ab.rollno)
          print('name :',ab.name)
          print('address :',ab.address)
          print('city :',ab.city)
          print('country :',ab.country)
          

l = []
for abcd in range(4): #from 0 to 9
     i = student()
     i.input_data()
     l.append(i)

print(l)

#search 
rollno = int(input('enter roll no :'))
for x in l:
     if x.Retroll() == rollno:
          x.disp()
          

#sorting
for i in range(0,len(l)):
     for j in range(i+1,len(l)):
          if l[i].Retroll() > l[j].Retroll():
               temp = l[i]
               l[i] = l[j]
               l[j] = temp


for x in l:
     x.disp()
     



               
               
     





          


     
     


