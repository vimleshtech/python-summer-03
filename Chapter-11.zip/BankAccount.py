class BankAccount:
     def newAccount(s):
          s.ac = int(input('enter account no:'))
          s.acname = input('enter name :')
          

     def show(s):
          print(s.ac)
          print(s.acname)
          
