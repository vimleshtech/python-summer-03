class taxpayer:
     def input_data(s): #			to input the data
          s.pan = input('enter pan no:')
          s.name = input('enter name:')
          s.income =float( input('enter income :'))
          global x
          x =100
          
          
     def disp(ab):#				to display the data
          print('pan no :',ab.pan)
          print('name :',ab.name)
          print('income :',ab.income)
          print('tax amount :',ab.tax)
          
     def calctax(s):#			to calculate the tax.
          if s.income <= 100000:
               s.tax = 0
          elif s.income <=200000:
               s.tax = s.income*.10
          elif s.income<=500000:
               s.tax = s.income*.15
          else:
               s.tax = s.income*.20
               
o =taxpayer()
o.input_data()
o.calctax()
o.disp()

print(x)

