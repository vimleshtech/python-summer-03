sal = input('enter salary :')  #default type is str

sal = int(sal) #convert str to int

if sal>=5000 and sal<=10000:
     hra = sal*.10
     da =sal*.05

elif sal>10000 and sal<=15000:
     hra = sal*.15
     da =sal*.08
else:
     hra =0
     da = 0

print('hra amt ',hra)
print('da amt ',da)


     
     


