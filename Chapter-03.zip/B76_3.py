x = 1

for i in range(1,10): #9 times

     if x%2 == 0:
          print(x*-1,end=',')
     else:
          print(x,end=',')

     x = x+3
     
     
     
