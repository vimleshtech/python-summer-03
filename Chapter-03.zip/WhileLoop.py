#
#while loop
i =1
while i<10:
     print(i)
     i=i+1


#print in reverse
i =10
while i>0:
     print(i)
     i =i-1


#wap to get sum of all even and odd numbers between 1 to 100
se =0
so = 0
i =1
while i<=100:
     if i%2 ==0: #is no is even
          se = se+i
     else:
          so = so+i


     i=i+1


print('sum of all even :',se)
print('sum of all odd :',so)

     
#wap to get sum and averae of given range
n1 =int( input('enter first no :'))
n2 =int( input('enter end no :'))

s = 0
counter = 0
while n1<=n2:

     s =s+n1
     n1=n1+1
     counter = counter+1
     
     
print(s)
print(s/counter)








          


     
