
#range(5) # 0 to <5   #default incrementer is 1
#range(0,5) # 0 to <5
#range(1,5) # 1 to <5
#range(1,5,1) # 1 to <5
#range(1,5,2) # 1 3
#range(5,0,-1) #5 4 3 2 1  from 5 to >0 

#break
for i in range(1,10): #from 1 to <10

     if i% 3 ==0:
          break #stop the loop           
     print(i)
     
#continue
for i in range(1,10): #from 1 to <10
     if i% 3 ==0:
          continue      
     print(i)

#1 2 4 5 7 8           
     
