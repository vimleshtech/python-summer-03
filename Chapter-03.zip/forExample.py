se =0
so =0
for x in range(1,101):
     if x%2==0:
          se=se+x
     else:
          so = so+x

print(se)
print(so)

     
