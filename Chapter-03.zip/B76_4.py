
num =1
inc = 0
for i in range(1,10):
     print(num,end=',')

     num = num+4+inc
     inc = inc+2
     
     
     
