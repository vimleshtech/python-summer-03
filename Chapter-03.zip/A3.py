
a =11
a = a*a
print(a)



#
a =11
a = a*a*a
print(a)




