import socket               # Import socket module
import random
s = socket.socket()         # Create a socket object

host = socket.gethostname() # Get local machine name
port = 1233                # Reserve a port for your service.
s.bind((host, port))        # Bind to the port

s.listen(10)                 # Now wait for client connection.
while True:
   c, addr = s.accept()     # Establish connection with client.
   
   print ('Got connection from', addr)
   otp = random.randint(1000,9999)
   print(otp)
   c.send(str(otp).encode())
   c.close()                # Close the connection
