import time
import threading 
#time module
t = time.localtime()
print(t)
print(t.tm_year)
print(t.tm_mon)
print(t.tm_mday)
print(t.tm_wday)
print(t.tm_yday)

print(t.tm_year,'-',t.tm_mon,'-',t.tm_mday)



def task1():
     for i in range(1,5):
          print(i)
          #time.sleep(2)
def task2():
     for i in range(1,5):
          print(i)
          #time.sleep(2)

p1 = threading.Thread(target=task1,name='job1')
p2 = threading.Thread(target=task2,name='job2')
p1.start()
p2.start()

#process life cycle : ready state - start - running
#- pause - resume - kill - suspende - sleep 



#task1()
#task2()


          
     
     
     
     
