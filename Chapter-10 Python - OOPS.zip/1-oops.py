class employee:
     def newemp(add):
          #print(add)
          add.eid = int(input('enter employee id :'))
          add.ename = input('enter employee name :')
          add.bsal = int(input('enter employee basic sal :'))


     def compute(b):
          #print(add)
          b.msal =b.bsal
          b.ysal = b.msal*12

     def __init__(add):
          print('object is created')
          add.eid =0
          add.ename =''
          add.bsal =0
          add.msal = 0
          add.ysal = 0

     def __del__(a):
          print(a,' is removed, u cannto use further')
          
     def show(self):
          #print(add)
          print('......Employee Dertail......')
          print('employee id :',self.eid)
          print('employee name :',self.ename)
          print('employee msal :',self.msal)
          print('employee ysal :',self.ysal)
          
#create object of class employee
o = employee()



e1 = employee()
e2 = employee()

o.compute()

e1.newemp()#error
o.newemp()
e2.newemp()

e1.compute()
e2.compute()
o.compute()

e2.show()
o.show()
e1.show()

del o
del e1
#print(o.show())


#print(o)
#print(e1)
#print(e2)

          


     

     


