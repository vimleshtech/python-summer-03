import mysql.connector as c

#create connection from python to database server
con = c.connect(host='localhost',user='root',password='root',database='pydb')

#create connection statement to execute sql command 
ab = con.cursor()


ab.execute('select * from users')

print(ab)

o = ab.fetchall()
#print(o)

for r in o:
     #print(r)
     print(r[1],r[2],r[4])
     







