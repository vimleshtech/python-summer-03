import mysql.connector as c

#create connection from python to database server
con = c.connect(host='localhost',user='root',password='root',database='pydb')

#create connection statement to execute sql command 
ab = con.cursor()

'''
connect()
cursor()
execute()
fetchall()
commit()
'''
while True:
     ch = input('enter 1 -insert 2-show 3-delete 4-update 5-search 0-exit')

     if ch =='1':
          uid  = input('enter  uid :')
          name  = input('enter new name :')
          email  = input('enter new email :')
          pwd  = input('enter new pwd :')
          ab.execute("insert into users(uid,name,email,pwd) values("+uid+",'"+name+"','"+email+"','"+pwd+"')") #read all rows
          con.commit()
          
          

     elif ch=='2':
          ab.execute('select * from users') #read all rows
          o = ab.fetchall()
          for r in o:
               print(r)

     elif ch=='3':
          uid  = input('enter uid :')
          ab.execute('delete from users where uid='+uid)
          con.commit() #to remove the rows 
          

     elif ch=='4':
          uid  = input('enter  existing uid :')
          name  = input('enter new name :')
          email  = input('enter new email :')
          pwd  = input('enter new pwd :')
          #"+name+"
          a ="update users set name='"+name+"',email='"+email+"', pwd='"+pwd+"' where uid="+uid
          print(a)
          ab.execute(a)
          con.commit()
          
          
          

     elif ch =='5':
          uid  = input('enter uid :')
          ab.execute('select * from users where uid='+uid) #read selected rows
          o = ab.fetchall()
          for r in o:
               print(r)

     elif ch =='0':
               break 
     else:
               print('invalid choice , plz try again !!!')





          
