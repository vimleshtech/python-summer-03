import pandas as pd
import numpy as np

df = pd.read_excel(r'C:\Users\vkumar15\Documents\Sandbox\Excel\Sample - Superstore.xls',sheet_name='Orders')
print(df.shape)
print(df.info())


print(df.groupby('Segment').sum()[['Sales','Profit','Quantity']])
print(df.groupby('Region').sum()[['Sales','Profit','Quantity']])

#DataScience
#get selected columns
print(df['Sales'])
print(df[['Sales','Profit']])

#group by

print(df.groupby('Segment').sum()) #show sum for all numeric col

print(df.groupby('Segment').sum()[['Sales','Profit','Quantity']])
print(df.groupby('Region').sum()[['Sales','Profit','Quantity']])
print(df.groupby('Region').min()[['Sales','Profit','Quantity']])
print(df.groupby('Region').max()[['Sales','Profit','Quantity']])
print(df.groupby('Region').size())
print(df.groupby('Region').count()[['Sales','Profit','Quantity']])

#order by
print(df.sort_values('Sales',ascending=True)) #in asc
print(df.sort_values('Sales',ascending=False)) #in desc


#drop the columns
df = df.drop(columns=['Segment'])
print(df.shape)


#where / search data
print(df[df['Profit']>1000])

df= df[df['Profit']>1000 ]
df = df[df['Sales']>100 ]

print(df)

##convert dataframe to list (2 Dimenssion)
data =df.values  #[[1,'',444],[11,'',444],[]]
print(data)
#print selected rows and column
#slicer
#all rows and 0 to 2 col
print(data[:,0:3])  #row index, col index

#show selected rows 1 to 9th and all columns
print(data[1:10,:])

#show selected rows and cols
print(data[1:4,1:5])


##add column
print(df.shape)


x = np.ones(42)
df['nc'] = x
print(df.shape)
print(df)


#will not write or save row index : index=False
df.to_csv(r'C:\Users\vkumar15\Documents\Sandbox\Excel\output.csv',index=False)
print('data is saved to file')







































      
      



























