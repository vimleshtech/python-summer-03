import pandas as p

cars = p.read_csv(r'C:\Users\vkumar15\Desktop\Learning & Training\Weekend\Sunday\mtcars.csv')
print(cars)

#print : stats
print(cars.describe())




           
##show corr
co = cars.corr()
co.to_csv('correlation_cars.csv')

