import pandas
from pandas.tools.plotting import scatter_matrix
import matplotlib.pyplot as plt

from sklearn import model_selection

from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC





url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
cols = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']

dataset = pandas.read_csv(url, names=cols)

#print(dataset)

print(dataset.head())
print(dataset.tail())

print(dataset.shape)
print(dataset.columns)

print(dataset.info())
print(dataset.describe())


#data distribuation
print(dataset.groupby('class').size())
print(dataset.groupby('class').max())
print(dataset.groupby('class').min())
print(dataset.groupby('class').sum())

##visualize
#dataset.plot() #default is line chart

#dataset.plot(kind='box')
#dataset.plot(kind='bar')

#subplot
#dataset.plot(kind='line',subplots=True)
#dataset.plot(kind='line',subplots=True,layout=(2,2))  
#plt.show()

#hist graph
#dataset.hist()
#plt.show()

#scatter_matrix(dataset)
#plt.show()



##x , y
#convert dataset to list/array
data = dataset.values
x = data[:,0:4] #all rows,  cols 0,1,2,3
y = data[:,4] #all rows ,and 4th
print(x)
print(y)     


##train and test
# 70:30 ,  60:40, 80:20, 75:25

X_train, X_validation, Y_train, Y_validation =model_selection.train_test_split(x, y, test_size=.20, random_state=7)


print(len(X_train))
print(len(X_validation))
print(len(Y_train))
print(len(Y_validation))


#models

models = []

models.append(('LR', LogisticRegression()))
models.append(('LDA', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('CART', DecisionTreeClassifier()))
models.append(('NB', GaussianNB()))
models.append(('SVM', SVC()))

#print(models)

out = []
for name,model in models:
     #print(name)
     kfold = model_selection.KFold(n_splits=10, random_state=7)
     cv_results = model_selection.cross_val_score(model, X_train, Y_train, cv=kfold, scoring='accuracy')

     #print(name, cv_results.mean(), cv_results.std())
     out.append((name,cv_results.mean()*100))          

print(out)

     
















