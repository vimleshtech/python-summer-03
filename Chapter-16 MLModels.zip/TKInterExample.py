from tkinter import *

o = Tk()

lbl1 = Label(text='Enter First Name :')
lbl1.pack()

txt1 = Entry()
txt1.pack()

lbl2 = Label(text='Enter Last name :')
lbl2.pack()

txt2 = Entry()
txt2.pack()

def eve():
     fn = txt1.get() #read data from entry box
     ln = txt2.get()
     name = fn+' '+ln
     print('full name is ',name)
     
btn = Button(text='Click Me',command=eve)
btn.pack()

o.mainloop()


