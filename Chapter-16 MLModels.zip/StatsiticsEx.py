from tkinter import * #tkinter : toolkit of interface
import statistics

o = Tk() #toolkit 

msg = Label(text='enter data  (comma seperated) :')
msg.pack() #show msg in window/frame

txt = Entry()
txt.pack()

out = Label(text='')
out.pack()

def show_stat():
     d = txt.get()
     c = d.split(',') #list
     n = []
     for i in c:
          n.append(int(i))


     print(statistics.mean(n))
     print(statistics.mode(n))
     print(statistics.median(n))
     print(statistics.variance(n))
     print(statistics.stdev(n))
     out.configure(text=str(statistics.mean(n))) #show data in in lable
     
     
     
     
btn = Button(text='Show Stats ',command=show_stat)
btn.pack()


o.mainloop() #show window 



print(statistics.mean(n))
