#if example:

amt = input('enter amt :')
amt = int(amt)
tax = 0

if amt>1000:
     tax = amt*.18 # amt*18/100



#out of condition
total = amt+tax
print(total)

     

