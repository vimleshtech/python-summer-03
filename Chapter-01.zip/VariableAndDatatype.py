#data type example:

#int
a = 11
print(type(a))

#float
a = 11.444
print(type(a))


#str
a = '11.444'
print(type(a))

#or
#float
a = "sklsh222"
print(type(a))

#bool
a = True
print(type(a))


#list
a = [11.444,44,3,3,True]
print(type(a))

#tuple
a = (11.444,44,3,3,True)
print(type(a))

#dict
a = {'a': 'alpha', 1: 'one', 'd': 200, 11: [111, 'raman', 'male']}
print(type(a))

#set
s ={'iphone','dove','iphone'}
print(type(s))















