a =44
b =55
c =a+b

print(c)
