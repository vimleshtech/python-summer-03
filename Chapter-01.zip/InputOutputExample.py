n1 = input('enter data :')
n2 = input('enter data :')

print(type(n1))
print(type(n2))


#convert string to int  or typecasting

s= int(n1) + int(n2)

print('sum of two numbers ',end='=')  #end with = instead of \n
print(s)
