#wap to show highest/greater no
a =  int(input('enter num  :'))
b =  int(input('enter num  :'))
c =  int(input('enter num  :'))


if a>b and a>c:
     print('a is greater')
elif b>a and b>c:
     print('b is greater')
else:
     print('c is greater')



#nested
if a>b:
     if a>c:
          print('a is greater')
     else:
          print('c is greater')
else:
     if b>c:
          print('b is greater')

     else:
          print('c is greater')
          


          
