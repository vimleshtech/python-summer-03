import pandas as pd

#create empty dataframe (table)
df = pd.DataFrame()
print(df)


#convert list to dataframe or table
emp = {
     'eid':[1,2,10,21,100],
     'name':['Aman','Raman','Ayush','Monika','Kshitiz'],
     'gender':['Male','Male','Male','Female','Male'],
     'salary':[45000,89000,120000,23000,89000]     
     }

tbl = pd.DataFrame(data=emp)
print(tbl)


#show all columns name
print(tbl.columns)
#show shape
print(tbl.shape)

#show info : data type of every column
print(tbl.info())


#print top given rows
print(tbl.head(3))


#print buttom given rows
print(tbl.tail(2))

#sort data
print(tbl.sort_values('salary',ascending=True))
print(tbl.sort_values('salary',ascending=False))
print(tbl.sort_values('name',ascending=False))


#group
print(tbl.groupby('gender').size())
print(tbl.groupby('gender').sum())
print(tbl.groupby('gender').max())
print(tbl.groupby('gender').min()['salary'])


#read particular coumn
print(tbl['name'])
print(tbl[['name','salary']])


#where : condition
o = tbl[tbl['salary']>50000]
print(o)

###save data to file
tbl.to_csv('employee.csv')
print('data is saved')












     























