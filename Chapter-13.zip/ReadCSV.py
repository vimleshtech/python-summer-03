import pandas as pd

a = pd.read_csv('employee.csv')
print(a)

