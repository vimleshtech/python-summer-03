import numpy as np

#generate data 
a = np.arange(1,10)
print(a)


a = np.arange(1,10,.2)
print(a)


#convert list to array
a =[1,2,3,4,5]
x= np.array(a)
print(x)

#list vs array
#list  : can contains multiple type data
#array : single type data
#list  : cannot iterate data without loop
#array : iterate the data and apply the function/expression automatically

print(a*2) # 1 2 3 4 5 1 2 3 4 5  
print(x*2) # 2 4 6 8 10

#shape
print(x.shape)


#multiple dimenssion#2 d
o = np.array([[1,2,3],[4,6,3],[9,1,2]])
print(o)

o2 = o*2

#T : transpose - convet row to column
print(o.T)

#
print(o.shape)

print(o)
print(o2)


#get sum of two array of two dimenssion
print(np.add(o,o2))
print(np.subtract(o,o2))
print(np.multiply(o,o2))
print(np.divide(o,o2))


###
a= [111,22,4344,555,666,22]
a = np.array(a)
print(a)

a = np.array(a).reshape(-1,1)#from index and col count
print(a)

a = np.array(a).reshape(-1,2)
print(a)


#zero
print(np.zeros(10))
print(np.ones(10))


#data type
print(type(a))


#change data type
a= [111,22,4344,555,666,22]
a = np.array(a,dtype=float)
print(a)








































