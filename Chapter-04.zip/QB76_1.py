
x =2

for i in range(1,10):
     print(x,end=' ')
     x = x*2


print()#line change 
#B76_2
for i in range(1,40,3):
     print(i,end=',')
     

     
