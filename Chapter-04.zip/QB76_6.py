for i in range(2,20,2):
     print('(',end='')
     
     for c in range(2,i+1,2):
          if c<i:
               print(c,end='+')
          else:
               print(c,end='')
     print(')',end='')


print()
#
for i in range(1,20,2):
     print('(',end='')
     
     for c in range(1,i+1,2):
          if c<i:
               print(c,end='+')
          else:
               print(c,end='')
     print(')',end='')
