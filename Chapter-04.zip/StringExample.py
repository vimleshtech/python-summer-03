s = input('enter string :')

print(s.upper())
print(s.lower())
print(s.title())
print(s.replace('a','xy'))
print(len(s))


print(s.count('h'))


o = list(s)
print(o)

o = s.split(' ')
print(o)

if s.isdigit():
     print('number value')
if s.isupper():
     print('in upper case')
if s.islower():
     print('in lower case')

if s.endswith('ab'):
     print('ending with ab')



     



     
