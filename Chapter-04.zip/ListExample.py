#list
a =[111,222,333,445,3333,33]

print('count of elements :',len(a))
print('highest  :',max(a))
print('lowest value ',min(a))

##example
data= [] #empty list

while True: #infinte

     ch = input('enter 1 for add 2 for show 3 for delete 4 for udpate 0 for exit')
          

     if ch=='1':
          #print('in add')
          d = input('enter data :')
          data.append(d)          
     elif ch=='2':
          #print('in show')
          print(data)
          
     elif ch=='3':
          
          #print('in del')
          val = input('enter value for deletion ')

          if val in data:
               data.remove(val)
          else:
               print('given value is not found')
               
                     

     elif ch=='4':
          #print('in update')

          val = input('enter existing val')

          for i in range(0,len(data)):

               if data[i] == val:
                    newval = input('enter new value :')
                    data[i] = newval

                    

          
          


     elif ch =='0':
          print('system is closed')
          break 

     else:
          print('invalid choice, plz try again !!!')
          




