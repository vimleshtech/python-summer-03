data = []

i =0
while  i<5: #from 0 to 4
     x = input('enter data  :') #default data type istr
     x = int(x) #type casting / convert str to int
     
     data.append(x)

     i=i+1
     
print(data)

