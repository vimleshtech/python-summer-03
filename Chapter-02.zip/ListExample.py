data = [] #blank list

x = input('enter data  :')
data.append(x)


x = input('enter data  :')
data.append(x)


x = input('enter data  :')
data.append(x)

print(data)

