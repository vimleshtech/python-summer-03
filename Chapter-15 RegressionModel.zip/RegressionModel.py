#https://github.com/vimleshtech/excel
import pandas as pd
from sklearn.linear_model import LinearRegression


emp  = {'eid':[11,22,1,2,3,6],
        'name':['Raman','Jatin','Divya','Ayush','Nitisha','Monika'],
        'gender':['Male','Male','Female','Male','Female','Female'],
        'exp':[2,4,1,6,3,8],
        'deg':[1,2,1,3,1,2],
        'sal':[34000,53000,28000,89000,71000,110000]}



emp = pd.DataFrame(data=emp)
print(emp)

#describe
print(emp.describe())

#corr
print(emp.corr())



##
x  = emp[['exp','deg']]
y   = emp['sal']

reg = LinearRegression()
reg.fit(x,y)

print(reg)
print(reg.intercept_)
print(reg.coef_)
















