import re # regular expression 
import tweepy #access to tweet app
from tweepy import OAuthHandler #authenication 
from textblob import TextBlob #text/tweet parse
 
# keys and tokens from the Twitter Dev Console
consumer_key = 'TL7RyLnfilYH6xaoAlS0XFDCg'
consumer_secret = 'u5uBn4P62PMIxT4uwUVTl1Ycx4rsfByFs6jl2e4SQ9zDjPIzCO'
access_token = '919434545924935681-2woCDEXuXQdhJewDaCRBqHBYmi5SFDN'
access_token_secret = 'T29jqUm6rZqsRYO7AGc47GlgYTaAaN5OtJD0DATo1uBjh'


auth = OAuthHandler(consumer_key, consumer_secret)
# set access token and secret
auth.set_access_token(access_token, access_token_secret)
# create tweepy API object to fetch tweets
api = tweepy.API(auth)

print('login is done')


def clean(tweet):
     return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t]) |(\w+:\/\/\S+)", " ", tweet).split())



def get_sentiment(tweet):
     analysis = TextBlob(clean(tweet))
     if analysis.sentiment.polarity > 0:
            return 'positive'
     elif analysis.sentiment.polarity == 0:
            return 'neutral'
     else:
            return 'negative'
          
     
leaders = ['Narendra Modi','Rahul Gandhi','Sonia Gandhi']
for l in leaders:
     
     tw = api.search(q=l,count=5)
     print('-------------------',l,'------------------')
     i =1
     data=[]
     for t in tw:
          #print(i,'----------:',t.text)
          
          #i=i+1
          out = get_sentiment(t.text)
          #print(out)
          data.append(out)
     print(data)
     
          
          
          
          



     


