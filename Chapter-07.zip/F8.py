
def test(x):
     if x%2==0:
          return 0
     else:
          return 1



print(test(11)) #1
print(test(12)) #0
print(test(16)) #0
print(test(19)) #1

