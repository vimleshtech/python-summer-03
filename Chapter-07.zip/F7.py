
def swap1(a,b):
     c =a
     a=b
     b=c
     print(a)
     print(b)
     


def swap2(a,b):
     b,a = a,b
     print(a)       
     print(b)

swap1(11,22)
swap2(11,22)
