
#new file will create if file is not exsit
o = open(r'C:\Users\vkumar15\Desktop\Sessions\Python-Session 18th Jun\test-data.txt','w')


#o.write('Hi, This is my test file \n') #\n : new line 
#o.write('end of file \n')

for i in range(0,6):
     s = input('enter string :')
     o.write(s+'\n')
     
o.close() #save and close the file



