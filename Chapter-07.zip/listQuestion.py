
a =[]

for i in range(0,5):
     x  = int(input('enter data :'))
     a.append(x)


print(a)
