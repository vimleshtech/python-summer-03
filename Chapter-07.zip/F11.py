
def odd_sum(n):

     s =0
     count = 0
     for i in range(1,n+1):
          if i%2 >0:#if odd 
               s =s+i
               count +=1

     print(s)
     print(s/count)



x = int(input('enter number :'))
odd_sum(x)

               
          
