
#default mode is : r 
o = open(r'C:\Users\vkumar15\Desktop\Sessions\Python-Session 18th Jun\test-data.txt')


#print(o.read())

#print(o.readline())
#print(o.readline())
#print(o.readline())

rows = o.readlines()
#print(rows)

#print no of rows in file
print(len(rows))

#read line by line using loop

#gender wise count
mc =0
fc=0
for r in rows:
     #print(r)
     c = r.split(',')
     print(c[1],c[3])
     if c[2]=='male':
          mc +=1
     elif c[2] =='female':
          fc +=1

print(mc)
print(fc)



          


          
     

