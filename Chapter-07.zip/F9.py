
def check_string(x):

     if x.islower():
               print('lower case')

     elif x.isupper():
          print('upper case')

     elif x.isdigit():
          print('digit ')

     else:
          print('special char')
          
          
check_string('a')

check_string('B')
check_string('%')
check_string('1')
