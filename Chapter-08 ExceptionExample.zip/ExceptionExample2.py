
a = int(input('enter a value:'))
b = int(input('enter b value:'))

try:
     if a==0 or b ==0:
          e = ZeroDivisionError('cannot be 0')
          raise e
     
     c =a*b
     print('c = ',c)
except ZeroDivisionError as m:
     print(m)
     
finally:
     print('end of the code')
     






