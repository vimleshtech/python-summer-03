

n = int(input('enter data :'))
d = int(input('enter data :'))


#div
try:
     
     #f = open('abc.txt')
     if d<0:
          msg= IndexError('divisor cannot be less than 0')
          raise msg        #go to label                    
     o = n/d #error 
     print(o)
except ZeroDivisionError as e:
     print(e)
except NameError as er:
     print(er)
except IndexError as e:
     print(e)
except FileNotFoundError as a:
     print(a)
except:
     #pass
     print('data is not correct')
finally:
     print('.... END .....')
#add
o =n+d
print(o)

