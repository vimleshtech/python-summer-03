import re

s = input('enter string :')

o = re.match('(.*) are (.*)',s)

print(o.groups())

if o:
     print('are is present')
else:
     print('not match')
     

#check the email id
email = input('enter gmail email id:')
o =re.search('@gmail.com$',email)
if o:
     print('correct gmail account')
else:
     print('incorrect gmail account')



     
     


